const rutasPorGestion = {
    tiendas: '../gestion/gestionar_tiendas.html',
    colaboradores: '../gestion/gestionar_colaboradores.html',
    login: '../login/index_login.html'
};

document.addEventListener('DOMContentLoaded', () => {

    function configurarBoton(idBoton, claveRuta) {
        const boton = document.getElementById(idBoton);
        if (boton) {
            boton.addEventListener('click', () => {
                const destino = rutasPorGestion[claveRuta];
                if (destino) {
                    window.location.href = destino;
                } else {
                    console.error(`La ruta para ${claveRuta} no está definida.`);
                }
            });
        } else {
            console.warn(`Botón no encontrado: ${idBoton}`);
        }
    }

    // Vinculamos cada botón de tu HTML con su ruta correspondiente
    configurarBoton('btn-tienda-ent-col', 'tiendas');
    configurarBoton('btn-colaboradores-ent-col', 'colaboradores');

    // CERRAR SESIÓN
    const btnLogout = document.querySelector('.boton-logout'); // usamos class porque no hay ID

    if (btnLogout) {
        btnLogout.addEventListener('click', () => {
            localStorage.clear();
            window.location.href = rutasPorGestion['login'];
        });
    } else {
        console.warn("Botón de logout no encontrado");
    }

});
